package com.cg.mywalletapp.repo;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import com.cg.mywalletapp.beans.Customer;

public class WalletRepoImpl implements WalletRepo {

	private static Map<String, Customer> data = null;
	private static List<String> myList= null;
 
	static {
		data= new HashMap<String, Customer>();
	}
	public Customer save(Customer customer) {
		return data.put(customer.getMobileNo(), customer);
	}

	public Customer findOne(String mobileNo) {
		Customer findMobile = null;
		if (data.containsKey(mobileNo)) {
			findMobile = data.get(mobileNo);
		}
		return findMobile;
		
		
	}

	public Map<String, Customer> getDetails() {
		 return  data;
			 
		 }
	public void addTransactions(String transactions) {
		myList.add(transactions);
	}
	public List<String> viewTransaction() {
		return myList;
		
	}
		
	}


