package com.cg.mywalletapp.service;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.mywalletapp.beans.Customer;
import com.cg.mywalletapp.beans.Wallet;
import com.cg.mywalletapp.exception.IMyException;
import com.cg.mywalletapp.exception.InsufficientBalanceException;
import com.cg.mywalletapp.exception.InvalidInputException;
import com.cg.mywalletapp.repo.WalletRepo;
import com.cg.mywalletapp.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService{
	WalletRepo repo = null;
	
	 public WalletServiceImpl() {
		repo = new WalletRepoImpl();
	}
	

	public Customer createAccount(Customer customer) {
		 return repo.save(customer);
		
	}

	public Customer showBalance(String mobileNo) {
		return repo.getDetails().get(mobileNo);
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		Customer senderFund = repo.findOne(sourceMobileNo);
		BigDecimal senderBalance = senderFund.getWallet().subtract(amount);
		senderFund.setWallet(senderBalance);
		Customer receiverFund = repo.findOne(targetMobileNo);
		BigDecimal receiverBalance = receiverFund.getWallet().add(amount);
		receiverFund.setWallet(receiverBalance);

		repo.addTransactions("From Account : " + sourceMobileNo+"To Account : " + targetMobileNo+ " Amount : " +amount);
		return repo.getDetails().get(sourceMobileNo);
		
		
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		Customer customer = new Customer();
		Map<String, Customer> details = repo.getDetails();
		Set<Entry<String, Customer>> entrySet = details.entrySet();
		Iterator<Entry<String, Customer>> it = entrySet.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Customer> entry = it.next();
			if (entry.getKey().equals(mobileNo)) {
			    customer = entry.getValue();
				
			}
		}
		BigDecimal depositeAmount = customer.getWallet().add(amount);
        customer.setWallet(depositeAmount);
    	repo.addTransactions("Amount Deposite :" +amount+"Balance : " +depositeAmount);
		return repo.getDetails().get(mobileNo);
	
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		Customer customer1 = new Customer();
		Map<String, Customer> details = repo.getDetails();
		Set<Entry<String, Customer>> entrySet = details.entrySet();
		Iterator<Entry<String, Customer>> it = entrySet.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Customer> entry = it.next();
			if (entry.getKey().equals(mobileNo)) {
			    customer1 = entry.getValue();
				
			}
		}
		BigDecimal withdrawAmount = customer1.getWallet().subtract(amount);
        customer1.setWallet(withdrawAmount);
        repo.addTransactions("Amount Withdraw : " +amount+"  Balance : " +withdrawAmount);
		return repo.getDetails().get(mobileNo);
		
	}
	public List<String>printTransactions() {
		return repo.viewTransaction();
	}


	public boolean validateCreateMethod(String name, String mobileNo)throws InvalidInputException {
		boolean result= false;
		if (name.trim().matches("^[A-Z a-z]*")) {
			if (mobileNo.matches("\\d{10}")) {
				result= true;
			} else {
				throw new InvalidInputException(IMyException.ERROR2);

			}
			
		} else {
			throw new InvalidInputException(IMyException.ERROR1);

		}
		return result;
	}


	public boolean validateBalance(BigDecimal balance,String mobileNo)throws InsufficientBalanceException {
		boolean result=false;
		BigDecimal amt = repo.findOne(mobileNo).getWallet();
	
		if(balance.compareTo(amt)==-1) {
		     result= true;
		
		}
		else {
			throw new InsufficientBalanceException(IMyException.ERROR3);
		}
		return result;
	}
    public boolean validateFundTransfer(BigDecimal balance,String mobileNo) throws InsufficientBalanceException {
    	boolean result=false;
		BigDecimal amt = repo.findOne(mobileNo).getWallet();
	
		if(balance.compareTo(amt)==-1) {
		     result= true;
		
		}
		else {
			throw new InsufficientBalanceException(IMyException.ERROR4);
		}
    	
    	return result;
    	
    	
    }


	

}
