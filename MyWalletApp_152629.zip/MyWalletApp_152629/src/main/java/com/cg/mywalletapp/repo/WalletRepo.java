package com.cg.mywalletapp.repo;

import java.util.List;
import java.util.Map;

import com.cg.mywalletapp.beans.Customer;

public interface WalletRepo {

	public Customer save(Customer customer);

	public Customer findOne(String mobileNo);

	public Map<String, Customer> getDetails();

	public void addTransactions(String transaction);

	public List<String> viewTransaction();
}
