package com.cg.mywalletapp.exception;

public interface IMyException {
	
	String ERROR1 = "Invalid Name. Try Again";
	String ERROR2 = "Invalid Number. Try Again";
	String ERROR3 = "Insufficient Balance .Try Again";
	String ERROR4 = "Transfer Failed. Try Again";

	

}
